﻿using System;
using System.Collections.Generic;

namespace CMCS_WPF.Models
{
    public enum UserRole { Lecturer, Coordinator, Manager }

    public class User
    {
        public int UserID { get; set; }
        public string FullName { get; set; }
        public UserRole Role { get; set; }
    }

    public class LecturerProfile
    {
        public int LecturerID { get; set; }
        public int UserID { get; set; }
        public decimal HourlyRate { get; set; }
        public string BankDetails { get; set; }
    }

    public class Claim
    {
        public int ClaimID { get; set; }
        public int LecturerID { get; set; }
        public int Month { get; set; }
        public int Year { get; set; }
        public decimal TotalHours { get; set; }
        public decimal Amount { get; set; }
        public string Status { get; set; }
        public DateTime SubmittedDate { get; set; }
    }
}