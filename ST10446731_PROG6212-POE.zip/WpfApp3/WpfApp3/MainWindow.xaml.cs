﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.ComponentModel; // Required for CancelEventArgs
using Microsoft.Win32;
using CMCS_WPF.Models;
using CMCS_WPF.Services;


namespace CMCS_WPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            // Load data when the application starts (Step 10.2)
            CMCS_WPF.Services.ClaimRepository.LoadClaims();

            InitializeComponent();

            // Attach the closing event handler to save data (Step 10.2)
            this.Closing += MainWindow_Closing;
        }

        private void MainWindow_Closing(object sender, CancelEventArgs e)
        {
            // Save data when the main window is closed (Step 10.2)
            CMCS_WPF.Services.ClaimRepository.SaveClaims();
        }

        private void Lecturer_Click(object sender, RoutedEventArgs e)
        {
            new LecturerWindow().Show();
        }

        private void Coordinator_Click(object sender, RoutedEventArgs e)
        {
            new CoordinatorWindow().Show();
        }

        private void Manager_Click(object sender, RoutedEventArgs e)
        {
            new ManagerWindow().Show();
        }

        // Handler for the HR/Finance button (Step 8.6)
        private void HR_Click(object sender, RoutedEventArgs e)
        {
            new HRWindow().Show();
        }
    }
}