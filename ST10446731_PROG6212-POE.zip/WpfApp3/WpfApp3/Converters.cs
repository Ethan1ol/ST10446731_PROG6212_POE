﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace CMCS_WPF
{
    // Converter to map a boolean value to a Color or SolidColorBrush
    // true = Green (Compliant), false = Red (Non-Compliant)
    public class BoolToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isCompliant)
            {
                // Return Green for Compliant, Red for Non-Compliant
                return isCompliant ? Brushes.Green : Brushes.Red;
            }
            return Brushes.Black; // Default color
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    // Converter to map a boolean value to Visibility
    // true = Visible, false = Collapsed. Used for the Failure Reason block.
    public class InverseBooleanToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool booleanValue)
            {
                // Inverse: if true (Compliant), hide (Collapsed). If false (Non-Compliant), show (Visible).
                return booleanValue ? Visibility.Collapsed : Visibility.Visible;
            }
            return Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}