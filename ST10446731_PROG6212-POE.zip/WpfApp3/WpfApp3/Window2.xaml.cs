﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Microsoft.Win32;
using CMCS_WPF.Models;
using CMCS_WPF.Services;

namespace CMCS_WPF
{
    public partial class CoordinatorWindow : Window
    {
        public CoordinatorWindow()
        {
            InitializeComponent();
            RefreshPendingList();
        }

        private void RefreshPendingList()
        {
            // The Coordinator only sees claims that are currently Pending
            PendingList.ItemsSource = null;
            PendingList.ItemsSource = CMCS_WPF.Services.ClaimRepository.GetPendingClaims();
        }

        private void Approve_Click(object sender, RoutedEventArgs e)
        {
            if (PendingList.SelectedItem is CMCS_WPF.Models.Claim claim)
            {
                // --------------------------------------------------------
                // NEW: AUTOMATED WORKFLOW ENFORCEMENT
                // Coordinator can ONLY approve claims that are Policy Compliant.
                // --------------------------------------------------------
                if (claim.IsPolicyCompliant)
                {
                    CMCS_WPF.Services.ClaimRepository.ApproveClaim(claim.ClaimID);
                    MessageBox.Show($"Claim {claim.ClaimID} from {claim.LecturerName} has been APPROVED.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    // If not compliant, prevent approval and advise the Coordinator to reject.
                    MessageBox.Show($"Claim {claim.ClaimID} is NOT Policy Compliant.\nReason: {claim.AutoCheckFailureReason}\n\nThis claim MUST be rejected.",
                                    "Approval Denied", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

                RefreshPendingList();
            }
            else
            {
                MessageBox.Show("Select a claim to approve.");
            }
        }

        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            if (PendingList.SelectedItem is CMCS_WPF.Models.Claim claim)
            {
                // Reject can be done regardless of compliance status. 
                // However, we include a message if the claim was Non-Compliant 
                // to confirm the automated system's findings were acted upon.

                string reasonMessage = "";
                if (!claim.IsPolicyCompliant)
                {
                    reasonMessage = $"\nReason for rejection includes Policy Non-Compliance: {claim.AutoCheckFailureReason}";
                }

                CMCS_WPF.Services.ClaimRepository.RejectClaim(claim.ClaimID);
                MessageBox.Show($"Claim {claim.ClaimID} from {claim.LecturerName} has been REJECTED.{reasonMessage}", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                RefreshPendingList();
            }
            else
            {
                MessageBox.Show("Select a claim to reject.");
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}