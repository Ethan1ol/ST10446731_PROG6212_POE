﻿using System;
using System.Collections.Generic;
using System.Linq;
using CMCS_WPF.Models;
using System.IO;
using System.Text.Json; // Required for data persistence

namespace CMCS_WPF.Services
{
    public static class ClaimRepository
    {
        private static readonly string DataFilePath = "claims_data.json"; // Data persistence file (Step 10.1)
        private static List<CMCS_WPF.Models.Claim> _claims = new List<CMCS_WPF.Models.Claim>();
        private static int _nextId = 1;

        // Method to load data from file (Step 10.1)
        public static void LoadClaims()
        {
            if (File.Exists(DataFilePath))
            {
                try
                {
                    string jsonString = File.ReadAllText(DataFilePath);
                    var loadedClaims = JsonSerializer.Deserialize<List<CMCS_WPF.Models.Claim>>(jsonString);

                    if (loadedClaims != null && loadedClaims.Any())
                    {
                        _claims = loadedClaims;
                        _nextId = _claims.Max(c => c.ClaimID) + 1;
                    }
                }
                catch (Exception)
                {
                    // Error loading data. Start with an empty list.
                }
            }
        }

        // Method to save data to file (Step 10.1)
        public static void SaveClaims()
        {
            try
            {
                var options = new JsonSerializerOptions { WriteIndented = true };
                string jsonString = JsonSerializer.Serialize(_claims, options);
                File.WriteAllText(DataFilePath, jsonString);
            }
            catch (Exception)
            {
                // Error saving data.
            }
        }

        public static void AddClaim(CMCS_WPF.Models.Claim claim)
        {
            claim.ClaimID = _nextId++;
            claim.Status = CMCS_WPF.Models.ClaimStatus.Pending;

            claim.PerformAutomatedCheck(); // Perform check on submission (Step 9.2)

            _claims.Add(claim);
        }

        public static List<CMCS_WPF.Models.Claim> GetAllClaims() => _claims;

        public static List<CMCS_WPF.Models.Claim> GetPendingClaims()
        {
            return _claims.Where(c => c.Status == CMCS_WPF.Models.ClaimStatus.Pending).ToList();
        }

        // Method for HR to retrieve claims ready for payment (Step 8.2)
        public static List<CMCS_WPF.Models.Claim> GetApprovedClaims()
        {
            return _claims.Where(c => c.Status == CMCS_WPF.Models.ClaimStatus.Approved).ToList();
        }

        // Method for HR to retrieve finalized claims for reporting (Step 11.2)
        public static List<CMCS_WPF.Models.Claim> GetPaidClaims()
        {
            return _claims.Where(c => c.Status == CMCS_WPF.Models.ClaimStatus.Paid).ToList();
        }


        public static void ApproveClaim(int claimId)
        {
            var claim = _claims.FirstOrDefault(c => c.ClaimID == claimId);
            if (claim != null)
                claim.Status = CMCS_WPF.Models.ClaimStatus.Approved;
        }

        public static void RejectClaim(int claimId)
        {
            var claim = _claims.FirstOrDefault(c => c.ClaimID == claimId);
            if (claim != null)
                claim.Status = CMCS_WPF.Models.ClaimStatus.Rejected;
        }

        // Method for HR to finalize the claim (Step 8.2)
        public static void FinalizeClaim(int claimId)
        {
            var claim = _claims.FirstOrDefault(c => c.ClaimID == claimId);
            if (claim != null)
                claim.Status = CMCS_WPF.Models.ClaimStatus.Paid;
        }
    }
}