﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls; // Added for TextChangedEventArgs
using Microsoft.Win32;
using CMCS_WPF.Models;
using CMCS_WPF.Services;
using System.IO;

namespace CMCS_WPF
{
    public partial class LecturerWindow : Window
    {
        private string _uploadedFilePath = null;

        public LecturerWindow()
        {
            InitializeComponent();
            ClaimsList.ItemsSource = CMCS_WPF.Services.ClaimRepository.GetAllClaims();
            // Initialize total display
            UpdateTotalAmount();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // ---------------------------------------------------------------------
        // NEW AUTO-CALCULATION LOGIC
        // ---------------------------------------------------------------------

        // This method is triggered by TextChanged event on both HoursBox and RateBox
        private void InputBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateTotalAmount();
        }

        private void UpdateTotalAmount()
        {
            // Attempt to safely parse hours and rate
            bool hoursValid = double.TryParse(HoursBox.Text, out double hours);
            bool rateValid = double.TryParse(RateBox.Text, out double rate);

            double totalAmount = 0.0;

            // Calculate total only if both inputs are valid and positive
            if (hoursValid && rateValid && hours > 0 && rate > 0)
            {
                totalAmount = hours * rate;
                ErrorBlock.Text = ""; // Clear error if inputs become valid
            }
            else
            {
                // Optionally show a calculation error, but keeping it clean for now.
                // ErrorBlock.Text = "Please enter valid positive numbers for calculation.";
            }

            // Display the calculated amount, formatted to 2 decimal places with 'R' prefix
            TotalAmountBlock.Text = $"R {totalAmount:N2}";
        }

        // ---------------------------------------------------------------------
        // END NEW AUTO-CALCULATION LOGIC
        // ---------------------------------------------------------------------

        private void UploadBtn_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Title = "Select supporting document (.pdf, .docx, .xlsx)",
                Filter = "Allowed Files|*.pdf;*.docx;*.xlsx|All Files|*.*"
            };

            if (dlg.ShowDialog() == true)
            {
                var fi = new FileInfo(dlg.FileName);
                if (fi.Length > 5 * 1024 * 1024)
                {
                    ErrorBlock.Text = "File too large. Max 5 MB.";
                    return;
                }

                _uploadedFilePath = dlg.FileName;
                UploadedFileNameBlock.Text = fi.Name;
            }
        }

        private void SubmitClaim_Click(object sender, RoutedEventArgs e)
        {
            // Existing validation: ensures hours and rate are valid numbers and > 0
            if (!double.TryParse(HoursBox.Text, out double hours) || hours <= 0)
            {
                ErrorBlock.Text = "Enter valid hours (must be a positive number).";
                return;
            }

            if (!double.TryParse(RateBox.Text, out double rate) || rate <= 0)
            {
                ErrorBlock.Text = "Enter valid hourly rate (must be a positive number).";
                return;
            }

            var claim = new CMCS_WPF.Models.Claim
            {
                // This LectuerName logic is temporary and should be replaced by a real user system
                LecturerName = $"Lecturer {CMCS_WPF.Services.ClaimRepository.GetAllClaims().Count + 1}",
                HoursWorked = hours,
                HourlyRate = rate,
                Notes = NotesBox.Text ?? "",
                Status = CMCS_WPF.Models.ClaimStatus.Pending
            };

            if (!string.IsNullOrEmpty(_uploadedFilePath) && File.Exists(_uploadedFilePath))
            {
                // NOTE: Improvement needed here to prevent overwriting files with the same name.
                var uploadsDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Uploads");
                if (!Directory.Exists(uploadsDir)) Directory.CreateDirectory(uploadsDir);
                var dest = Path.Combine(uploadsDir, Path.GetFileName(_uploadedFilePath));
                File.Copy(_uploadedFilePath, dest, true);
                claim.UploadedFilePath = dest;
            }

            CMCS_WPF.Services.ClaimRepository.AddClaim(claim);
            ClaimsList.ItemsSource = null;
            ClaimsList.ItemsSource = CMCS_WPF.Services.ClaimRepository.GetAllClaims();

            HoursBox.Text = "";
            RateBox.Text = "";
            NotesBox.Text = "";
            UploadedFileNameBlock.Text = "";
            _uploadedFilePath = null;
            ErrorBlock.Text = "Claim submitted successfully.";

            // Call to reset the total amount display after successful submission
            UpdateTotalAmount();
        }
    }
}