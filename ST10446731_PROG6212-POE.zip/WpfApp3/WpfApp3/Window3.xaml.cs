﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Microsoft.Win32;
using CMCS_WPF.Models;
using CMCS_WPF.Services;

namespace CMCS_WPF
{
    public partial class ManagerWindow : Window
    {
        public ManagerWindow()
        {
            InitializeComponent();
            RefreshList();
        }

        private void RefreshList()
        {
            // The Manager views all claims regardless of status
            ApprovalList.ItemsSource = null;
            ApprovalList.ItemsSource = CMCS_WPF.Services.ClaimRepository.GetAllClaims();
        }

        private void Approve_Click(object sender, RoutedEventArgs e)
        {
            if (ApprovalList.SelectedItem is CMCS_WPF.Models.Claim claim)
            {
                // --------------------------------------------------------
                // NEW: AUTOMATED WORKFLOW OVERRIDE LOGIC
                // Manager can approve, but requires confirmation for Non-Compliant claims.
                // --------------------------------------------------------
                bool proceedWithApproval = true;
                string message = $"Claim {claim.ClaimID} from {claim.LecturerName} has been APPROVED.";

                // 1. Check if the claim is Pending
                if (claim.Status != ClaimStatus.Pending)
                {
                    // Optionally prevent re-approving a finalized claim, or allow it with a warning
                    var result = MessageBox.Show($"Claim {claim.ClaimID} is already {claim.Status}. Do you want to forcibly set the status to APPROVED?",
                                                 "Status Conflict", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.No)
                    {
                        return;
                    }
                }

                // 2. Check if the claim is NOT Policy Compliant
                if (!claim.IsPolicyCompliant)
                {
                    string warningMessage = $"WARNING: This claim is NOT Policy Compliant!\n\nReason(s): {claim.AutoCheckFailureReason}\n\nDo you wish to override the policy check and approve the claim anyway?";

                    // Force the Manager to acknowledge the violation
                    var result = MessageBox.Show(warningMessage, "Policy Override Required", MessageBoxButton.YesNo, MessageBoxImage.Warning);

                    if (result == MessageBoxResult.No)
                    {
                        proceedWithApproval = false;
                        message = $"Approval of Claim {claim.ClaimID} cancelled due to policy violation.";
                    }
                    // If result is Yes, proceedWithApproval remains true.
                }

                if (proceedWithApproval)
                {
                    CMCS_WPF.Services.ClaimRepository.ApproveClaim(claim.ClaimID);
                    MessageBox.Show(message, "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show(message, "Action Cancelled", MessageBoxButton.OK, MessageBoxImage.Information);
                }

                RefreshList();
            }
            else
            {
                MessageBox.Show("Select a claim to approve.");
            }
        }

        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            if (ApprovalList.SelectedItem is CMCS_WPF.Models.Claim claim)
            {
                // Manager can reject any claim without special checks.
                CMCS_WPF.Services.ClaimRepository.RejectClaim(claim.ClaimID);
                MessageBox.Show($"Claim {claim.ClaimID} from {claim.LecturerName} has been REJECTED.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                RefreshList();
            }
            else
            {
                MessageBox.Show("Select a claim to reject.");
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}