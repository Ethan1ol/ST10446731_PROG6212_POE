﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using Microsoft.Win32;

namespace CMCS_WPF.Models
{
    public enum ClaimStatus
    {
        Pending,
        Approved,
        Rejected,
        Paid // Added for HR/Finance view (Step 8.1)
    }

    public class Claim
    {
        public int ClaimID { get; set; }
        public string LecturerName { get; set; }
        public double HoursWorked { get; set; }
        public double HourlyRate { get; set; }
        public string Notes { get; set; }
        public string UploadedFilePath { get; set; }
        public ClaimStatus Status { get; set; }

        // Auto-calculated property
        public double TotalAmount => HoursWorked * HourlyRate;

        // Properties for Automation Check (Step 9.1)
        public bool IsPolicyCompliant { get; private set; }
        public string AutoCheckFailureReason { get; private set; }

        // Method to perform Automated Check (Step 9.1)
        public void PerformAutomatedCheck()
        {
            var reasons = new List<string>();

            // 1. Hours Limit Check (Must be <= 100 hours)
            if (HoursWorked > 100)
            {
                reasons.Add($"Hours Worked ({HoursWorked}) exceeds the 100-hour limit.");
            }

            // 2. Hourly Rate Limit Check (Must be <= R250)
            if (HourlyRate > 250)
            {
                reasons.Add($"Hourly Rate (R{HourlyRate:F2}) exceeds the R250 limit.");
            }

            // 3. Total Amount Limit Check (Must be <= R10,000)
            if (TotalAmount > 10000)
            {
                reasons.Add($"Total Claim Amount (R{TotalAmount:N2}) exceeds the R10,000 limit.");
            }

            // 4. Document Check (Must have a supporting document)
            if (string.IsNullOrEmpty(UploadedFilePath))
            {
                reasons.Add("Missing supporting document.");
            }

            // Set the final status and reason
            IsPolicyCompliant = !reasons.Any();
            AutoCheckFailureReason = IsPolicyCompliant
                ? "Passed All Checks"
                : string.Join(" | ", reasons);
        }
    }
}