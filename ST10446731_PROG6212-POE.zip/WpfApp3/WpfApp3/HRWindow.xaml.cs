﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using CMCS_WPF.Models;
using CMCS_WPF.Services;
using System.IO; // Required for file operations (Step 11.3)
using System.Text; // Required for StringBuilder (Step 11.3)

namespace CMCS_WPF
{
    public partial class HRWindow : Window
    {
        public HRWindow()
        {
            InitializeComponent();
            RefreshApprovedList();
        }

        private void RefreshApprovedList()
        {
            // HR only views claims that have been Approved and are not yet Paid
            HRList.ItemsSource = null;
            HRList.ItemsSource = ClaimRepository.GetApprovedClaims();
        }

        private void MarkAsPaid_Click(object sender, RoutedEventArgs e)
        {
            if (HRList.SelectedItem is CMCS_WPF.Models.Claim claim)
            {
                var result = MessageBox.Show($"Are you sure you want to mark Claim ID {claim.ClaimID} (R{claim.TotalAmount:N2}) as PAID?",
                                             "Confirm Payment Finalization",
                                             MessageBoxButton.YesNo,
                                             MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    CMCS_WPF.Services.ClaimRepository.FinalizeClaim(claim.ClaimID);
                    MessageBox.Show($"Claim {claim.ClaimID} from {claim.LecturerName} has been marked as PAID.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    RefreshApprovedList();
                }
            }
            else
            {
                MessageBox.Show("Select an approved claim to mark as paid.");
            }
        }

        // Handler for Generate Report button (Step 11.3)
        private void GenerateReport_Click(object sender, RoutedEventArgs e)
        {
            var paidClaims = ClaimRepository.GetPaidClaims();

            if (!paidClaims.Any())
            {
                MessageBox.Show("No claims have been marked as PAID yet to generate a report.", "No Data", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var sb = new StringBuilder();

            // Report Header
            sb.AppendLine("CONTRACT MONTHLY CLAIM SYSTEM - PAYMENT REPORT");
            sb.AppendLine($"Date Generated: {DateTime.Now:yyyy-MM-dd HH:mm}");
            sb.AppendLine("------------------------------------------------------------------------------------------------------------------------------------");

            // CSV/Tabular Header
            sb.AppendLine("Claim ID\tLecturer Name\tHours\tRate\tTotal Amount (R)\tPolicy Compliant\tFinalized Date");

            // Data Rows (uses LINQ)
            foreach (var claim in paidClaims)
            {
                sb.AppendLine($"{claim.ClaimID}\t{claim.LecturerName}\t{claim.HoursWorked}\t{claim.HourlyRate}\t{claim.TotalAmount:N2}\t{claim.IsPolicyCompliant}\t{DateTime.Now:yyyy-MM-dd}");
            }

            // Total Summary
            var totalPaid = paidClaims.Sum(c => c.TotalAmount);
            sb.AppendLine("------------------------------------------------------------------------------------------------------------------------------------");
            sb.AppendLine($"TOTAL AMOUNT TO BE DISBURSED: R{totalPaid:N2} for {paidClaims.Count} Claims");

            // Save the file
            string reportFileName = $"Payment_Report_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Reports", reportFileName);

            try
            {
                string reportsDir = Path.GetDirectoryName(filePath);
                if (!Directory.Exists(reportsDir)) Directory.CreateDirectory(reportsDir);

                File.WriteAllText(filePath, sb.ToString());
                MessageBox.Show($"Payment Report successfully generated and saved to the 'Reports' folder:\n{filePath}", "Report Saved", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving report: {ex.Message}", "File Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}