﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows; // for WPF windows
using Microsoft.Win32; // for file dialogs if needed
using CMCS_WPF.Models;
using CMCS_WPF.Services;

namespace CMCS_WPF.Models
{
    public enum ClaimStatus
    {
        Pending,
        Approved,
        Rejected
    }

    public class Claim
    {
        public int ClaimID { get; set; }
        public string LecturerName { get; set; }
        public double HoursWorked { get; set; }
        public double HourlyRate { get; set; }
        public string Notes { get; set; }
        public string UploadedFilePath { get; set; }
        public ClaimStatus Status { get; set; }
        public double TotalAmount => HoursWorked * HourlyRate;
    }
}
