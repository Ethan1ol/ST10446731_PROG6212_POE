﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows; // for WPF windows
using Microsoft.Win32; // for file dialogs if needed
using CMCS_WPF.Models;
using CMCS_WPF.Services;


namespace CMCS_WPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Lecturer_Click(object sender, RoutedEventArgs e)
        {
            new LecturerWindow().Show();
        }

        private void Coordinator_Click(object sender, RoutedEventArgs e)
        {
            new CoordinatorWindow().Show();
        }

        private void Manager_Click(object sender, RoutedEventArgs e)
        {
            new ManagerWindow().Show();
        }
    }
}
