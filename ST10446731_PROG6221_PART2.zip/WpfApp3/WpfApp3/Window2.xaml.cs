﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows; // for WPF windows
using Microsoft.Win32; // for file dialogs if needed
using CMCS_WPF.Models;
using CMCS_WPF.Services;

namespace CMCS_WPF
{
    public partial class CoordinatorWindow : Window
    {
        public CoordinatorWindow()
        {
            InitializeComponent();
            RefreshPendingList();
        }

        private void RefreshPendingList()
        {
            PendingList.ItemsSource = null;
            PendingList.ItemsSource = CMCS_WPF.Services.ClaimRepository.GetPendingClaims();
        }

        private void Approve_Click(object sender, RoutedEventArgs e)
        {
            if (PendingList.SelectedItem is CMCS_WPF.Models.Claim claim)
            {
                CMCS_WPF.Services.ClaimRepository.ApproveClaim(claim.ClaimID);
                RefreshPendingList();
            }
            else
            {
                MessageBox.Show("Select a claim to approve.");
            }
        }

        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            if (PendingList.SelectedItem is CMCS_WPF.Models.Claim claim)
            {
                CMCS_WPF.Services.ClaimRepository.RejectClaim(claim.ClaimID);
                RefreshPendingList();
            }
            else
            {
                MessageBox.Show("Select a claim to reject.");
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
