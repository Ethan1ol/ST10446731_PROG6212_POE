﻿using System.Collections.Generic;
using System.Linq;
using CMCS_WPF.Models;

using System.Collections.Generic;
using System.Linq;

namespace CMCS_WPF.Services
{
    public static class ClaimRepository
    {
        private static readonly List<CMCS_WPF.Models.Claim> _claims = new List<CMCS_WPF.Models.Claim>();
        private static int _nextId = 1;

        public static void AddClaim(CMCS_WPF.Models.Claim claim)
        {
            claim.ClaimID = _nextId++;
            claim.Status = CMCS_WPF.Models.ClaimStatus.Pending;
            _claims.Add(claim);
        }

        public static List<CMCS_WPF.Models.Claim> GetAllClaims() => _claims;

        public static List<CMCS_WPF.Models.Claim> GetPendingClaims()
        {
            return _claims.Where(c => c.Status == CMCS_WPF.Models.ClaimStatus.Pending).ToList();
        }

        public static void ApproveClaim(int claimId)
        {
            var claim = _claims.FirstOrDefault(c => c.ClaimID == claimId);
            if (claim != null)
                claim.Status = CMCS_WPF.Models.ClaimStatus.Approved;
        }

        public static void RejectClaim(int claimId)
        {
            var claim = _claims.FirstOrDefault(c => c.ClaimID == claimId);
            if (claim != null)
                claim.Status = CMCS_WPF.Models.ClaimStatus.Rejected;
        }
    }
}

