using System.Windows;

namespace CMCS_WPF
{
    public partial class App : Application
    {
    }
}
