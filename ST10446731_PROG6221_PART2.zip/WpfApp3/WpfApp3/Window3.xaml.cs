﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows; // for WPF windows
using Microsoft.Win32; // for file dialogs if needed
using CMCS_WPF.Models;
using CMCS_WPF.Services;

namespace CMCS_WPF
{
    public partial class ManagerWindow : Window
    {
        public ManagerWindow()
        {
            InitializeComponent();
            RefreshList();
        }

        private void RefreshList()
        {
            ApprovalList.ItemsSource = null;
            ApprovalList.ItemsSource = CMCS_WPF.Services.ClaimRepository.GetAllClaims();
        }

        private void Approve_Click(object sender, RoutedEventArgs e)
        {
            if (ApprovalList.SelectedItem is CMCS_WPF.Models.Claim claim)
            {
                CMCS_WPF.Services.ClaimRepository.ApproveClaim(claim.ClaimID);
                RefreshList();
            }
            else
            {
                MessageBox.Show("Select a claim to approve.");
            }
        }

        private void Reject_Click(object sender, RoutedEventArgs e)
        {
            if (ApprovalList.SelectedItem is CMCS_WPF.Models.Claim claim)
            {
                CMCS_WPF.Services.ClaimRepository.RejectClaim(claim.ClaimID);
                RefreshList();
            }
            else
            {
                MessageBox.Show("Select a claim to reject.");
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
