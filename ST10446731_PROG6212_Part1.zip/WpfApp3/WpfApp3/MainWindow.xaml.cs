﻿using System.Windows;

namespace CMCS_WPF
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Lecturer_Click(object sender, RoutedEventArgs e)
        {
            new LecturerWindow().Show();
        }

        private void Coordinator_Click(object sender, RoutedEventArgs e)
        {
            new CoordinatorWindow().Show();
        }

        private void Manager_Click(object sender, RoutedEventArgs e)
        {
            new ManagerWindow().Show();
        }
    }
}

