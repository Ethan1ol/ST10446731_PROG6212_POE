﻿using System.Windows;

namespace CMCS_WPF
{
    public partial class LecturerWindow : Window
    {
        public LecturerWindow()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); 
        }
    }
}

